# Johnsons Punt Club — Web Upload + WhatsApp Broadcast (Twilio)

## What this app does (simple + reliable)
- Admin logs into a clean dashboard
- Upload a Sportsbet bet receipt screenshot (image)
- Select the Punter (dropdown)
- App stores the bet + receipt image
- App broadcasts a WhatsApp message to ALL active members (1 message per member)

This avoids inbound WhatsApp bot complexity and still notifies everyone.

## Run locally
1) Python 3.10+
2) Install:
   pip install -r requirements.txt
3) Create .env from example:
   cp .env.example .env
4) Run:
   uvicorn app.main:app --reload --port 8000
5) Open:
   http://localhost:8000

## Twilio WhatsApp (Sandbox test)
- Use TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
- Each member must join the sandbox by sending the join code to that number (Twilio console shows it).
