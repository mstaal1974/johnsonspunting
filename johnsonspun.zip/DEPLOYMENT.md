# Deployment step-by-step

This app needs environment variables:
- ADMIN_PASSWORD
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_WHATSAPP_FROM

## Platform A — Local (fastest)
1) Install Python 3.10+
2) pip install -r requirements.txt
3) Copy .env.example -> .env and fill values
4) Run: uvicorn app.main:app --reload --port 8000
5) Open http://localhost:8000

### WhatsApp Sandbox test
1) In Twilio Console > Messaging > Try it out > Send a WhatsApp message
2) Note the sandbox number and join code
3) Each club member sends the join code to the sandbox number (one-time opt-in)
4) Add their numbers in the dashboard (Members page)
5) Upload a receipt and click "Save + Notify"

## Platform B — Render (cheap/free)
1) Create a Render account
2) New > Web Service
3) Connect your GitHub repo (or upload this code to GitHub)
4) Build command:
   pip install -r requirements.txt
5) Start command:
   uvicorn app.main:app --host 0.0.0.0 --port 10000
6) Add Environment Variables in Render:
   - ADMIN_PASSWORD
   - TWILIO_ACCOUNT_SID
   - TWILIO_AUTH_TOKEN
   - TWILIO_WHATSAPP_FROM
   - (optional) OPENAI_API_KEY, OPENAI_MODEL
7) Deploy and open your Render URL

Note: For long-term hosted use, switch to Postgres (Render/Railway provide free tiers).

## Platform C — Railway (cheap/free)
1) Create Railway project
2) Deploy from GitHub
3) Add variables:
   - ADMIN_PASSWORD
   - TWILIO_ACCOUNT_SID
   - TWILIO_AUTH_TOKEN
   - TWILIO_WHATSAPP_FROM
4) Start command:
   uvicorn app.main:app --host 0.0.0.0 --port $PORT
5) Deploy

Recommended: add Railway Postgres plugin and set DATABASE_URL.

## Platform D — VPS (most control)
1) Install Python + nginx
2) Run uvicorn behind nginx (TLS)
3) Set env vars
4) Prefer Postgres for durability
