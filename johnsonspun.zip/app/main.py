from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from app.db import init_db
from app.routes import ui

app = FastAPI(title="Johnsons Punt Club — Web Upload + WhatsApp Broadcast")

app.add_middleware(SessionMiddleware, secret_key="CHANGE_THIS_SECRET_IN_PROD")

app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.mount("/uploads", StaticFiles(directory="data/uploads"), name="uploads")

@app.on_event("startup")
def _startup():
    init_db()

app.include_router(ui.router)
