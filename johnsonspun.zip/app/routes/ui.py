import uuid
from pathlib import Path
from fastapi import APIRouter, Request, Depends, Form, UploadFile, File
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.deps import get_db
from app.models import Member, Bet
from app.services.auth import is_admin, check_password
from app.services.seed import PUNTERS
from app.services.twilio_service import send_whatsapp_broadcast
from app.services.vision_service import extract_from_sportsbet_receipt
from app.db import UPLOADS_DIR

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

def admin_required(request: Request):
    if not is_admin(request):
        return RedirectResponse("/login", status_code=303)
    return None

@router.get("/login")
def login_get(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None})

@router.post("/login")
def login_post(request: Request, password: str = Form(...)):
    if check_password(password):
        request.session["is_admin"] = True
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", {"request": request, "error": "Wrong password"})

@router.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)

@router.get("/")
def home(request: Request, db: Session = Depends(get_db)):
    if not is_admin(request):
        return RedirectResponse("/login", status_code=303)
    bets = db.query(Bet).order_by(Bet.id.desc()).limit(50).all()
    return templates.TemplateResponse("index.html", {"request": request, "bets": bets})

@router.get("/members")
def members(request: Request, db: Session = Depends(get_db)):
    redir = admin_required(request)
    if redir: return redir
    if db.query(Member).count() == 0:
        for n in PUNTERS:
            db.add(Member(name=n, whatsapp_number="", active=True))
        db.commit()
    members = db.query(Member).order_by(Member.name.asc()).all()
    return templates.TemplateResponse("members.html", {"request": request, "members": members})

@router.post("/members/update")
def members_update(
    request: Request,
    member_id: int = Form(...),
    whatsapp_number: str = Form(""),
    active: str = Form("off"),
    db: Session = Depends(get_db),
):
    redir = admin_required(request)
    if redir: return redir
    m = db.query(Member).filter(Member.id == member_id).first()
    if m:
        m.whatsapp_number = whatsapp_number.strip()
        m.active = (active == "on")
        db.commit()
    return RedirectResponse("/members", status_code=303)

@router.get("/new-bet")
def new_bet_get(request: Request, db: Session = Depends(get_db)):
    redir = admin_required(request)
    if redir: return redir
    punters = [m.name for m in db.query(Member).order_by(Member.name.asc()).all()] or PUNTERS
    return templates.TemplateResponse("new_bet.html", {"request": request, "punters": punters})

@router.post("/new-bet")
async def new_bet_post(
    request: Request,
    punter_name: str = Form(...),
    notify_all: str = Form("on"),
    bookmaker: str = Form("Sportsbet"),
    event: str = Form(""),
    selection: str = Form(""),
    bet_type: str = Form(""),
    odds: str = Form(""),
    stake: str = Form(""),
    potential_returns: str = Form(""),
    bet_id: str = Form(""),
    notes: str = Form(""),
    receipt: UploadFile = File(None),
    db: Session = Depends(get_db),
):
    redir = admin_required(request)
    if redir: return redir

    image_path = None
    extracted = None

    if receipt is not None and receipt.filename:
        ext = Path(receipt.filename).suffix.lower() or ".jpg"
        fname = f"{uuid.uuid4().hex}{ext}"
        dest = UPLOADS_DIR / fname
        content = await receipt.read()
        dest.write_bytes(content)
        image_path = f"/uploads/{fname}"

        try:
            extracted = extract_from_sportsbet_receipt(content)
        except Exception:
            extracted = None

    def to_float(x):
        try:
            x = (x or "").strip().replace("$","")
            return float(x) if x else None
        except Exception:
            return None

    b = Bet(
        punter_name=punter_name.strip(),
        bookmaker=(bookmaker or "").strip() or (extracted.get("bookmaker") if extracted else None),
        event=(event or "").strip() or (extracted.get("event") if extracted else None),
        selection=(selection or "").strip() or (extracted.get("selection") if extracted else None),
        bet_type=(bet_type or "").strip() or (extracted.get("bet_type") if extracted else None),
        odds=to_float(odds) if odds.strip() else (extracted.get("odds") if extracted else None),
        stake=to_float(stake) if stake.strip() else (extracted.get("stake") if extracted else None),
        potential_returns=to_float(potential_returns) if potential_returns.strip() else (extracted.get("potential_returns") if extracted else None),
        bet_id=(bet_id or "").strip() or (extracted.get("bet_id") if extracted else None),
        image_path=image_path,
        notes=(notes or "").strip() or (extracted.get("note") if extracted else None),
    )
    db.add(b)
    db.commit()

    sent = 0
    errors = []
    if notify_all == "on":
        members = db.query(Member).filter(Member.active == True).all()  # noqa
        to_numbers = [m.whatsapp_number for m in members if (m.whatsapp_number or "").strip()]
        msg = build_broadcast_message(b)
        try:
            sent, errors = send_whatsapp_broadcast(to_numbers, msg)
        except Exception as e:
            errors = [{"error": str(e)}]

    return templates.TemplateResponse("new_bet_done.html", {"request": request, "bet": b, "sent": sent, "errors": errors})

def build_broadcast_message(b: Bet) -> str:
    parts = [f"New bet: {b.punter_name}"]
    if b.stake is not None:
        parts.append(f"Stake ${b.stake:.2f}")
    if b.bet_type:
        parts.append(b.bet_type)
    if b.event:
        parts.append(b.event)
    if b.selection:
        parts.append(b.selection)
    if b.odds is not None:
        parts.append(f"odds {b.odds:g}")
    if b.potential_returns is not None:
        parts.append(f"Return ${b.potential_returns:.2f}")
    if b.bet_id:
        parts.append(f"ID {b.bet_id}")
    return " — ".join(parts)

@router.get("/bets")
def bets(request: Request, db: Session = Depends(get_db)):
    redir = admin_required(request)
    if redir: return redir
    bets = db.query(Bet).order_by(Bet.id.desc()).limit(500).all()
    return templates.TemplateResponse("bets.html", {"request": request, "bets": bets})
