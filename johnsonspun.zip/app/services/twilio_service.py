import os
from typing import List, Tuple
from twilio.rest import Client

def send_whatsapp_broadcast(to_numbers: List[str], message: str) -> Tuple[int, list]:
    sid = os.getenv("TWILIO_ACCOUNT_SID")
    token = os.getenv("TWILIO_AUTH_TOKEN")
    from_ = os.getenv("TWILIO_WHATSAPP_FROM", "whatsapp:+14155238886")

    if not sid or not token:
        raise RuntimeError("Missing TWILIO_ACCOUNT_SID or TWILIO_AUTH_TOKEN")

    client = Client(sid, token)

    sent = 0
    errors = []
    for to in to_numbers:
        if not to:
            continue
        to = to.strip()
        if not to.startswith("whatsapp:"):
            to = "whatsapp:" + to
        try:
            client.messages.create(from_=from_, to=to, body=message)
            sent += 1
        except Exception as e:
            errors.append({"to": to, "error": str(e)})
    return sent, errors
