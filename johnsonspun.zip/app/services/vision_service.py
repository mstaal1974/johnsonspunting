"""Sportsbet receipt extraction (placeholder).

This starter version does NOT run AI extraction yet.
It is wired so you can enable extraction later without changing the UI flow.
"""

from typing import Dict, Any

def extract_from_sportsbet_receipt(image_bytes: bytes) -> Dict[str, Any]:
    return {
        "bookmaker": "Sportsbet",
        "bet_id": None,
        "event": None,
        "selection": None,
        "bet_type": None,
        "odds": None,
        "stake": None,
        "potential_returns": None,
        "confidence": 0.0,
        "note": "Auto-extraction not enabled"
    }
