import os
from fastapi import Request

def is_admin(request: Request) -> bool:
    return bool(request.session.get("is_admin", False))

def check_password(pw: str) -> bool:
    return pw == os.getenv("ADMIN_PASSWORD", "change_me")
