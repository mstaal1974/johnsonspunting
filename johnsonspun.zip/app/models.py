from sqlalchemy import Column, Integer, String, DateTime, Text, Float, Boolean
from sqlalchemy.sql import func
from app.db import Base

class Member(Base):
    __tablename__ = "members"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, index=True, nullable=False)
    whatsapp_number = Column(String(50), nullable=True)
    active = Column(Boolean, default=True, nullable=False)

class Bet(Base):
    __tablename__ = "bets"
    id = Column(Integer, primary_key=True, index=True)
    punter_name = Column(String(100), index=True, nullable=False)
    bookmaker = Column(String(50), nullable=True)
    event = Column(String(255), nullable=True)
    selection = Column(String(255), nullable=True)
    bet_type = Column(String(50), nullable=True)
    odds = Column(Float, nullable=True)
    stake = Column(Float, nullable=True)
    potential_returns = Column(Float, nullable=True)
    bet_id = Column(String(100), nullable=True)
    image_path = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
